Miguel Zavala
5/22/20
CISC481-Intro to AI
Dr. Rahmat
HW6: Perceptron and Logistic Regression

How to run:
python3 perceptron_logisticreg.py


You are prompted to enter input for methods Perceptron 'P' or Logistic Regression 'L', followed by a series of
sized-3 tuples (x1,x2,y):

Example input for Perceptron: (copy and paste line below to into when prompted 'Enter input:', then you can add more tuples)
P (0, 2,+1) (2, 0, -1) (0, 4,+1) (4, 0, -1)

Example input for Logistic Regression: (copy and paste line below to into when prompted 'Enter input:', then you can add more tuples)
L (0, 2,+1) (2, 0, -1) (0, 4, -1) (4, 0, +1) (0, 6, -1) (6, 0, +1)


Note:
-the first character of input MUST be 'P' or 'L' characters
-make sure the tuples are actual tuples using '(', ')'
-tuples must be in the format: (int,int,1) OR (int,int,-1)